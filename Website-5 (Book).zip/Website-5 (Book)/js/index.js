// ---------- Navbar scrolling -------------
$(document).ready(function () {
    $(window).scroll(function () {
        if ($(window).scrollTop() > 60) {
            $('.navbar').addClass('navbar-scroll');
        } else {
            $('.navbar').removeClass('navbar-scroll');
        }
    });

    // ---------- Banner Slider -------------
    $(".slider-area").slick({
        dots: true,
        isfinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        speed: 500,
        responsive: [
            {
                breakpoint: 767,
                settings: {
                    dots: true,
                    isfinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }
        ]
    });

    // ----------- Pagination ------------
    $('.next').click(function () {
        $('.pagination').find('.pageNumber.active').next().addClass('active');
        $('.pagination').find('.pageNumber.active').prev().removeClass('active');
    });
    $('.prev').click(function () {
        $('.pagination').find('.pageNumber.active').prev().addClass('active');
        $('.pagination').find('.pageNumber.active').next().removeClass('active');
    });

    // ----------- Author Slider ------------
    $('.carousel').owlCarousel({
        margin: 20,
        loop: true,
        autoplay:true,
        autoplayTimeOut: 2000,
        autoplayHoverPause: true,
        speed:300,
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            600: {
                items: 2,
                nav: false
            },
            1000: {
                items: 3,
                nav: false
            }
        }
    });
});



